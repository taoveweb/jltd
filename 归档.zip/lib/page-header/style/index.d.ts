import '../../breadcrumb/style';
import '../../tabs/style';
import './index.less';
