import * as React from 'react';
export declare function getBreadcrumb(breadcrumbNameMap: any, url: string): any;
declare type PageHeaderProps = {
    routes?: any[];
    params?: object;
    location?: object;
    breadcrumbNameMap?: object;
};
declare type PageHeaderState = {
    breadcrumb: null;
};
export default class PageHeader extends React.PureComponent<PageHeaderProps, PageHeaderState> {
    state: {
        breadcrumb: null;
    };
    componentDidMount(): void;
    componentDidUpdate(preProps: any): void;
    onChange: (key: any) => void;
    getBreadcrumbProps: () => {
        routes: any;
        params: any;
        routerLocation: any;
        breadcrumbNameMap: any;
    };
    getBreadcrumbDom: () => void;
    conversionFromProps: () => JSX.Element;
    conversionFromLocation: (routerLocation: any, breadcrumbNameMap: any) => JSX.Element;
    /**
     * 将参数转化为面包屑
     * Convert parameters into breadcrumbs
     */
    conversionBreadcrumbList: () => JSX.Element | null;
    itemRender: (route: any, params: any, routes: any, paths: any) => JSX.Element;
    render(): JSX.Element;
}
export {};
