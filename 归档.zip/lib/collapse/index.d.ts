import { Collapse } from 'antd';
export default Collapse;
