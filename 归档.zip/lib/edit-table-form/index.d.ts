import * as React from 'react';
/**
 * 可编辑Table的表单
 */
interface EditTableProps {
    getRefForm: any;
    columns: any;
    dataSource: any;
    loading: any;
    onClickRow: any;
    pagination: any;
    rowSelection: any;
    tableWidth: any;
    form: any;
}
declare const EditTableForm: React.ComponentClass<import("../../../../../../../Users/sinoservices/Documents/new/jlt-design/node_modules/antd/lib/form/Form").RcBaseFormProps & Pick<EditTableProps, "loading" | "rowSelection" | "pagination" | "dataSource" | "columns" | "getRefForm" | "onClickRow" | "tableWidth">, React.ComponentState>;
export default EditTableForm;
