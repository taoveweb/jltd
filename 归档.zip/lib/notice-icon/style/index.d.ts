import '../../avatar/style';
import '../../list/style';
import '../../popover/style';
import '../../icon/style';
import '../../badge/style';
import '../../spin/style';
import './index.less';
import './NoticeList.less';
