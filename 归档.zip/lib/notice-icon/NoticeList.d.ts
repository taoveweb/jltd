/// <reference types="react" />
export default function NoticeList({ data, onClick, onClear, title, locale, emptyText, emptyImage, }: any): JSX.Element;
