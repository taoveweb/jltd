import { PureComponent } from 'react';
interface INoticeIconProps {
    children?: any;
    onItemClick?: any;
    onTabChange?: any;
    oading?: any;
    locale?: any;
    onClear?: any;
    loading?: any;
    className?: any;
    count?: any;
    popupAlign?: any;
    onPopupVisibleChange?: any;
    popupVisible?: any;
}
interface INoticeIconState {
    tabType?: any;
}
export default class NoticeIcon extends PureComponent<INoticeIconProps, INoticeIconState> {
    static Tab: any;
    static defaultProps: {
        onItemClick: () => void;
        onPopupVisibleChange: () => void;
        onTabChange: () => void;
        onClear: () => void;
        loading: boolean;
        locale: {
            emptyText: string;
            clear: string;
        };
        emptyImage: string;
    };
    constructor(props: INoticeIconProps);
    onItemClick: (item: any, tabProps: any) => void;
    onTabChange: (tabType: any) => void;
    getNotificationBox(): JSX.Element | null;
    render(): JSX.Element;
}
export {};
