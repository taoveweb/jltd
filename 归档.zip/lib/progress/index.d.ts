import { Progress } from 'antd';
export default Progress;
