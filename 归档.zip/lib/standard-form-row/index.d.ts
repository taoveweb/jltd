/// <reference types="react" />
declare const StandardFormRow: ({ title, children, last, block, grid, ...rest }: any) => JSX.Element;
export default StandardFormRow;
