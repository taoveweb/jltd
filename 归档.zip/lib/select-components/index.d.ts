import * as React from 'react';
declare type SelectComponentsState = {
    dataDictionaryList: undefined[];
    value: null;
};
interface SelectComponentsprops {
    allowClear: any;
    defaultValue: any;
    autoFocus: any;
    defaultActiveFirstOption: any;
    disabled: any;
    dropdownClassName: any;
    dropdownMatchSelectWidth: any;
    firstActiveValue: any;
    labelInValue: any;
    mode: any;
    notFoundContent: any;
    placeholder: any;
    showArrow: any;
    showSearch: any;
    size: any;
    tokenSeparators: any;
    style: any;
    codeType: any;
    url: any;
    onSelectChange: any;
    onBlur: any;
    onDeselect: any;
    onFocus: any;
    onMouseEnter: any;
    onMouseLeave: any;
    onPopupScroll: any;
    onSearch: any;
    onSelect: any;
}
declare class SelectComponents extends React.Component<SelectComponentsprops, SelectComponentsState> {
    constructor(props: SelectComponentsprops);
    componentWillMount(): void;
    onSelectChange: (value: any) => void;
    selectData: () => void;
    render(): JSX.Element;
}
export default SelectComponents;
