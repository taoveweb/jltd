import * as React from 'react';
declare type ExceptionModalComponentsState = {
    visible: boolean;
    errorData: null;
    errorId: null;
};
interface ExceptionModalComponentsprops {
    visible: any;
    errorData: any;
    errorId: any;
}
declare class ExceptionModalComponent extends React.Component<ExceptionModalComponentsprops, ExceptionModalComponentsState> {
    constructor(props: ExceptionModalComponentsprops);
    visibleCheck(): boolean;
    errorDateCheck(): boolean;
    componentWillReceiveProps(nextprops: ExceptionModalComponentsprops): void;
    exceptionModelCancel: () => void;
    onExceptionModelConfirm: () => void;
    render(): JSX.Element;
}
export default ExceptionModalComponent;
