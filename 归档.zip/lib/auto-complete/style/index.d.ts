import 'antd/lib/style/index.less';
import 'antd/lib/auto-complete/style/index.less';
import 'antd/lib/select/style';
