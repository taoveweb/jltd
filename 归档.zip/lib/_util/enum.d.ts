declare const Enum: {
    DEFAULT_PAGE_NUMBER: number;
    DEFAULT_PAGE_SIZE: number;
    BTN_TYPE: {
        text: string;
        value: string;
    }[];
    storageCondition: {
        text: string;
        value: number;
    }[];
    sex: {
        text: string;
        value: string;
    }[];
    orderType: {
        text: string;
        value: string;
    }[];
    importStatus: {
        text: string;
        value: string;
    }[];
    type: {
        text: string;
        value: string;
    }[];
    isConsignor: {
        text: string;
        value: number;
    }[];
    isConsignee: {
        text: string;
        value: number;
    }[];
    isWh: {
        text: string;
        value: number;
    }[];
    nature: {
        text: string;
        value: string;
    }[];
    driverLicenseType: {
        text: string;
        value: string;
    }[];
    status: {
        text: string;
        value: string;
    }[];
    industry: {
        text: string;
        value: string;
    }[];
    transportCondition: {
        text: string;
        value: number;
    }[];
    yesOrNo: {
        text: string;
        value: string;
    }[];
    packType: {
        text: string;
        value: string;
    }[];
    isBalanceObject: {
        text: string;
        value: string;
    }[];
    SdiDeviceType: {
        text: string;
        value: string;
    }[];
    DeviceType: {
        text: string;
        value: string;
    }[];
    DB_LENGTH_LIMIT: {
        TWENTY_THREE: {
            VALUE: number;
        };
        TWENTY_SIX: {
            VALUE: number;
        };
        FIFTY_THREE: {
            VALUE: number;
        };
        TEN: {
            VALUE: number;
        };
        TWELVE_TWO: {
            VALUE: number;
        };
        TEN_ZERO: {
            VALUE: number;
        };
        EIGHTEEN_TWO: {
            VALUE: number;
        };
        EIGHT_TWO: {
            VALUE: number;
        };
    };
    business_industry: {
        text: string;
        value: string;
    }[];
    manufacturer: {
        text: string;
        value: string;
    }[];
    equipmentStatus: {
        text: string;
        value: string;
    }[];
    equipmentType: {
        text: string;
        value: string;
    }[];
    supplierName: {
        text: string;
        value: string;
    }[];
    isCarDevice: {
        text: string;
        value: string;
    }[];
    carTypeName: {
        text: string;
        value: string;
    }[];
    SdiSdiProducer: {
        text: string;
        value: string;
    }[];
    SdiDeviceStatus: {
        text: string;
        value: string;
    }[];
    IS_MINUNIT: {
        text: string;
        value: string;
    }[];
    WarehouseWwWhType: {
        label: string;
        value: string;
    }[];
    wsTypeEn: {
        label: string;
        value: string;
    }[];
    subType: {
        label: string;
        value: string;
    }[];
    /**
     * 行内编辑
     */
    EDIT_TYPE_LINE: string;
    /**
     * 操作编辑
     */
    EDIT_TYPE_OPERATE: string;
    /**
     * 默认新增的单位信息，最小单位"否"
     */
    IS_MINUNIT_DEFAULT: string;
    /**
     * 最小单位"是"
     */
    IS_MINUNIT_YES: string;
    DATE_FORMAT: string;
    /**
     * 车辆所属
     */
    CAR_ATTACH: string;
    /**
     * 车辆类型
     */
    VEHICLE_TYPE: string;
    /**
     * 双人运输方式
     */
    DOU_TRANSPORT_VM: string;
    /**
     * 车长
     */
    VEHICLE_LENGTH: string;
    /**
     * 燃料类型
     */
    FUEL_TYPE: string;
    /**
     * 设备类型
     */
    DEVICE_TYPE: string;
    /**
     * 厂商
     */
    DEVICE_PRODUCER: string;
    /**
     * 人员性质
     */
    PERSON_NATURE: string;
    /**
     * 性别
     */
    GENDER: string;
    /**
     * 驾驶证类型
     */
    DRIVING_TYPE: string;
    IS_SETTLEMENT: string;
    PACK_TYPE: string;
    INDUSTRY_CLASSFIFY: string;
    TRANSPORT_CONDITION: string;
    STORAGE_CONDITION: string;
    SHELF_LIFE_UNIT: string;
    MAINTAIN_LEVEL: string;
    DRUG_TYPE: string;
    DRUG_ATTRIBUTE: string;
    MEDICINE_DRUG_TYPE: string;
    /**
     * 类型（网点覆盖）
     */
    TYPE_BRANCH_CONVER: string;
    /**
     * 干线
     */
    MAIN_LINE: string;
    /**
     * 层级
     */
    HIERARCHY: string;
    /**
     * 默认提示
     */
    DEFAULT_PLACEHOLDER: string;
    /**
     * 默认提示
     */
    DEFAULT_SELECT_PLACEHOLDER: string;
    BUSINESS_INDUSTRY: string;
    /**
     * 启用
     */
    ENABLE_STATUS: string;
    /**
     * 禁用
     */
    DISABLE_STATUS: string;
    /**
     * 是否最小单位
     */
    DATACATIONRY_IS_MINUNIT: string;
    /**
     * 行内编辑保存提示
     */
    PLEASE_SAVE_INFO_MSG: string;
    IS_WH: string;
    DRUG_FORM: string;
    /**
     * 司机状态启用
     */
    DRIVER_ENABLE_STATUS: string;
    /**
     * 司机状态禁用
     */
    DRIVER_DISABLE_STATUS: string;
    /**
     *是否默认
     */
    IS_DEFAULT: string;
    /**
     *是否默认 :否
     */
    IS_DEFAULT_STATUS_N: string;
    /**
     *是否默认 :是
     */
    IS_DEFAULT_STATUS_Y: string;
    /**
     *开通系统用户
     */
    IS_OPEN_SYSTEM_USER: string;
    DRUG_ATTRIBUTE_DEFAULT: string;
    DRUG_TYPE_DEFAULT: string;
    CAR_ATTACH_DEFAULT: string;
    VEHICLE_TYPE_DFAULT: string;
    FUEL_TYPE_DEFAULT: string;
    /**
     *仓库设备状态启用
     */
    DEVICE_ENABLE_STATUS: string;
    DEVICE_DISABLE_STATUS: string;
    Default_N: string;
    Default_ZERO: string;
    /**
     * 生成账单方式
     */
    BE_ACCOUNT_TYPE: string;
    /**
     * 业务类型
     */
    ACCOUNT_BUSINESSTYPE: string;
    /**
     * 记账周期
     */
    ACCOUNT_CYCLE: string;
    /**
     * 启用
     */
    ACCOUNT_ENABLE_STATUS: string;
    /**
     * 停用
     */
    ACCOUNT_DISABLE_STATUS: string;
    /**
     * 是否（通用，是：Y；否：N）
     */
    YES_OR_NO: string;
    /**
     * 是否（通用，是：1；否：0）
     */
    WHETHER: string;
    /**
     * 启用状态（通用，启用：1；停用：0）
     */
    IS_ENABLE: string;
    /**
     * 启用状态（通用，启用：Y；停用：N）
     */
    IS_ENABLE_CN: string;
    /**
     * 收发货方类型
     */
    NEW_CONTACT_TYPE: string;
    /**
     * 默认时间格式
     */
    DEFAULT_FORMAT_TIME: string;
    /**
     * 对账周期-按天
     */
    ACCOUNT_CYCLE_BY_DAY: string;
    /**
     * 是否默认（是）
     */
    IS_DEFAULT_YES: string;
    /**
     * 是否默认（否）
     */
    IS_DEFAULT_NOT: string;
};
export default Enum;
