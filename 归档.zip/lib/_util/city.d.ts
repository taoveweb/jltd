declare let DICT_FIXED: {
    id: number;
    pid: number;
    parentId: number;
}[];
export default DICT_FIXED;
