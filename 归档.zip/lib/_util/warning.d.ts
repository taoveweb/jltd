declare const _default: (valid: boolean, message: string) => void;
export default _default;
