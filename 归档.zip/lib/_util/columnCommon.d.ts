/// <reference types="react" />
declare const _default: {
    formatterString: (val: any) => JSX.Element;
};
export default _default;
