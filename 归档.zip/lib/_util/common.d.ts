declare const _default: {
    initColumns: (listCode: any, self: any) => any;
    escapeString: (text: any) => any;
    calculateObjectValue: (key: any, value: any, self: any) => any;
    defaultPageParam: () => {
        name: string;
        value: number;
    }[];
    pageParam: (pageNumber: any, pageSize: any) => {
        name: string;
        value: any;
    }[];
    pagination: () => {
        showQuickJumper: boolean;
        defaultCurrent: number;
        showSizeChanger: boolean;
        showTotal: (total: any) => string;
    };
    formatNum: (value: any, point: any) => any;
};
export default _default;
