export declare function urlToList(url: string): string[];
