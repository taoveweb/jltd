declare const _default: {
    isNotEmpty: (param: any) => boolean;
    isNotNull: (param: any) => boolean;
    isNotspace: (param: any) => boolean;
    isNull: (param: any) => boolean;
    isEmpty: (param: any) => boolean;
};
export default _default;
