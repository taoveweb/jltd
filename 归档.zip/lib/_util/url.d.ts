declare const url: any;
export default url;
