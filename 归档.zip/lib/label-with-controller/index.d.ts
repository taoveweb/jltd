/// <reference types="react" />
import RanderRange from './RanderRange';
export interface LabelWithControllerProps {
    isRequire?: boolean;
    type: string;
    label: string;
    onChange: (e?: any, c?: any, d?: any) => void;
    value?: string;
    isIconRequire?: boolean;
    className?: string;
    placeholder?: any;
    optionData?: Array<{
        value: string;
        text: string;
    }>;
    radioData?: Array<{
        value: string;
        text: string;
    }>;
    monetary?: string;
    viewStyle?: string;
    disabled?: boolean;
    title?: string;
    min?: number;
    max?: number;
    step?: number;
    formatter?: any;
    parser?: any;
    precision?: any;
    defaultValue?: any;
    maxLength?: any;
    onClick?: (e?: any) => void;
    readOnly?: any;
    onBlur?: (e?: any) => void;
    rows?: any;
    onSearch?: (e?: any) => void;
    suffix?: any;
    filterOption?: any;
    dropdownMatchSelectWidth?: any;
    mode?: any;
    format?: any;
    showTime?: any;
    DateBegin?: any;
    DateEnd?: any;
    options?: any;
    codeType?: any;
    labelClass?: any;
    span?: any;
    style?: any;
    minValue?: any;
    maxValue?: any;
}
declare const LabelWithController: (props: LabelWithControllerProps) => JSX.Element;
export default LabelWithController;
export { RanderRange };
