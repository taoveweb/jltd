import * as React from 'react';
interface RanderRangeProps {
    onChange?: any;
    minValue?: any;
    maxValue?: any;
    min?: any;
    max?: any;
}
declare class RanderRange extends React.Component<RanderRangeProps, {}> {
    onMaxChange: (maxValue: any) => void;
    onMinChange: (minValue: any) => void;
    render(): JSX.Element;
}
export default RanderRange;
