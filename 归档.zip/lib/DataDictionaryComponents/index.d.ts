import * as React from 'react';
declare type DataDictionaryComponentsState = {
    dataDictionaryList: undefined[];
    loading: boolean;
};
interface DataDictionaryComponentsprops {
    codeType?: any;
    dropdownMatchSelectWidth?: any;
    style?: any;
    placeholder?: any;
    value?: any;
    disabled?: any;
    allowClear?: any;
    defaultValue?: any;
    onChange?: any;
    className?: any;
    mode?: any;
    editable?: any;
}
declare class DataDictionaryComponents extends React.Component<DataDictionaryComponentsprops, DataDictionaryComponentsState> {
    constructor(props: DataDictionaryComponentsprops);
    componentWillMount(): void;
    searchTemplateForState: () => void;
    render(): JSX.Element;
}
export default DataDictionaryComponents;
