export declare function getAuthority(): string;
export declare function setAuthority(authority: any): void;
