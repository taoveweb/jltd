declare let Authorized: any;
declare const reloadAuthorized: () => void;
export { reloadAuthorized };
export default Authorized;
