import * as React from 'react';
/**
 * Recursively flatten the data
 * [{path:string},{path:string}] => [path,path2]
 * @param  menu
 */
export declare const getFlatMenuKeys: (menu: any) => any;
/**
 * Find all matched menu keys based on paths
 * @param  flatMenuKeys: [/abc, /abc/:id, /abc/:id/info]
 * @param  paths: [/abc, /abc/11, /abc/11/info]
 */
export declare const getMenuMatchKeys: (flatMenuKeys: any, paths: any) => any;
export interface SiderMenuProps {
    menuData: any;
    location: any;
    isMobile: any;
    onCollapse: any;
    Authorized: any;
    collapsed: any;
}
export interface SiderMenuState {
    openKeys: any;
    iconWidth: any;
}
export default class SiderMenu extends React.PureComponent<SiderMenuProps, SiderMenuState> {
    flatMenuKeys: any;
    constructor(props: SiderMenuProps);
    componentWillReceiveProps(nextProps: any): void;
    /**
     * Convert pathname to openKeys
     * /list/search/articles = > ['list','/list/search']
     * @param  props
     */
    getDefaultCollapsedSubMenus(props: SiderMenuProps): any;
    /**
     * 判断是否是http链接.返回 Link 或 a
     * Judge whether it is http link.return a or Link
     * @memberof SiderMenu
     */
    getMenuItemPath: (item: any) => JSX.Element;
    /**
     * get SubMenu or Item
     */
    getSubMenuOrItem: (item: any) => JSX.Element | null;
    /**
     * 获得菜单子节点
     * @memberof SiderMenu
     */
    getNavMenuItems: (menusData: any) => any;
    getSelectedMenuKeys: () => any;
    conversionPath: (path: any) => any;
    checkPermissionItem: (authority: any, ItemDom: any) => any;
    isMainMenu: (key: any) => any;
    handleOpenChange: (openKeys: any) => void;
    toggle: () => void;
    render(): JSX.Element;
}
