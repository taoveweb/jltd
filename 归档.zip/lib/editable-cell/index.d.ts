import * as React from 'react';
export interface EditableCellProps {
    getEditRowFormRef?: any;
    rows?: any;
    placeholder?: any;
    className?: any;
    DateEnd?: any;
    DateBegin?: any;
    viewStyle?: any;
    filterOption?: any;
    radioData?: any;
    optionData?: any;
    fieldId?: any;
    defaultValue?: any;
    style?: any;
    dropdownMatchSelectWidth?: any;
    disabled?: boolean | string;
    onBlur?: (e?: any) => void;
    onChange: (e?: any, b?: any, c?: any) => void | any;
    onClick?: (e?: any) => void;
    maxLength?: number;
    type?: string;
    editable?: any;
    value: string;
    field?: string;
    fieldOption?: any;
    form?: any;
}
declare class EditableCell extends React.Component<EditableCellProps> {
    private fieldOption;
    constructor(props: EditableCellProps);
    componentDidMount(): void;
    componentWillReceiveProps(nextPorps: EditableCellProps): void;
    /**
     * 创建FormItem
     * formItemProps: FormItem的属性
     * fieldId: 控件的id，唯一标识
     * fieldOption: getFieldDecorator方法传入的option
     * field： 组件
     */
    createFormItem: (field: any) => JSX.Element;
    createHiddenInput: (field: any) => JSX.Element;
    convertFormInfo: () => JSX.Element;
    editComponents: () => JSX.Element | undefined;
    render(): JSX.Element;
}
export default EditableCell;
