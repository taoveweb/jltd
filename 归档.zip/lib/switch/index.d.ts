import { Switch } from 'antd';
export default Switch;
