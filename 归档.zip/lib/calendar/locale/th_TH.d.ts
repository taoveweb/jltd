import th_TH from '../../date-picker/locale/th_TH';
export default th_TH;
