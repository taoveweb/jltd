import is_IS from '../../date-picker/locale/is_IS';
export default is_IS;
