import sl_SI from '../../date-picker/locale/sl_SI';
export default sl_SI;
