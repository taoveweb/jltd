import uk_UA from '../../date-picker/locale/uk_UA';
export default uk_UA;
