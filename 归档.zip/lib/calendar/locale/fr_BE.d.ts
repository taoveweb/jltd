import fr_BE from '../../date-picker/locale/fr_BE';
export default fr_BE;
