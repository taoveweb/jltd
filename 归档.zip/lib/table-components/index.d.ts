import * as React from 'react';
declare type TableComponentsState = {
    tableDataSource: any[];
};
interface TableComponents {
    tableColumns: any[];
    isEditable: any;
    isDeleteable: any;
    isAddable: any;
    isSave: any;
    isCancel: any;
    tableData: any;
    selectedRowKeys: string;
    tableWidth: number;
    rowKey: any;
    loading: boolean;
    onChange: any;
    pagination: object | false;
    onDelete: any;
    onSelect: any;
    onEdit: any;
    onAdd: any;
}
declare class TableComponents extends React.Component<TableComponents, TableComponentsState> {
    private columns;
    private cacheData;
    constructor(props: TableComponents);
    componentWillReceiveProps(nextProps: TableComponents): void;
    onSelectChange: (selectedRowKeys: any, selectedRows: any) => void;
    getTableDataSource(tableData?: never[], isAddable?: boolean): any;
    getLastTableDataMap: (key: any) => any;
    handleChange: (value: any, record: any, column: any) => void;
    delete(index: any): void;
    edit(index: any): void;
    save(index: any): void;
    add(key: any): void;
    cancel(index: any): void;
    renderColumns: (text: any, record: any, column: any) => JSX.Element;
    render(): JSX.Element;
}
export default TableComponents;
