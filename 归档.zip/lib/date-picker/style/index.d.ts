import 'antd/lib/style/index.less';
import 'antd/lib/date-picker/style/index.less';
import 'antd/lib/input/style';
import 'antd/lib/time-picker/style';
