declare const locale: {
    lang: any;
    timePickerLocale: {
        placeholder: string;
    };
};
export default locale;
