/**
 * Created by Andrey Gayvoronsky on 13/04/16.
 */
declare const locale: {
    lang: any;
    timePickerLocale: {
        placeholder: string;
    };
};
export default locale;
