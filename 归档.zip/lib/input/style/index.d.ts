import 'antd/lib/style/index.less';
import 'antd/lib/input/style/index.less';
import 'antd/lib/button/style';
