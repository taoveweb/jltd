/// <reference types="react" />
export default function Result({ className, type, title, description, extra, actions, ...restProps }: any): JSX.Element;
