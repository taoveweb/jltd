/// <reference types="react" />
declare const NumberInfo: ({ theme, title, subTitle, total, subTotal, status, suffix, gap, ...rest }: any) => JSX.Element;
export default NumberInfo;
