import 'antd/lib/locale-provider/style/index.less';
