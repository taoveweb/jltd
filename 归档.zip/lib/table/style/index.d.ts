import 'antd/lib/style/index.less';
import 'antd/lib/table/style/index.less';
import 'antd/lib/radio/style';
import 'antd/lib/checkbox/style';
import 'antd/lib/dropdown/style';
import 'antd/lib/spin/style';
import 'antd/lib/pagination/style';
