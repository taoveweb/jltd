/// <reference types="react" />
declare const DescriptionList: ({ className, title, col, layout, gutter, children, size, ...restProps }: any) => JSX.Element;
export default DescriptionList;
