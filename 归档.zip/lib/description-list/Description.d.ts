declare const Description: any;
export default Description;
