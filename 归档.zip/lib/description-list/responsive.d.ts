declare const _default: {
    1: {
        xs: number;
    };
    2: {
        xs: number;
        sm: number;
    };
    3: {
        xs: number;
        sm: number;
        md: number;
    };
    4: {
        xs: number;
        sm: number;
        md: number;
    };
};
export default _default;
