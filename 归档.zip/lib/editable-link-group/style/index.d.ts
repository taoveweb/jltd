import '../../button/style';
import './index.less';
