import { PureComponent } from 'react';
declare class EditableLinkGroup extends PureComponent {
    static propTypes: {
        links: any;
        onAdd: any;
        linkElement: any;
    };
    static defaultProps: {
        links: never[];
        onAdd: () => void;
        linkElement: string;
    };
    render(): JSX.Element;
}
export default EditableLinkGroup;
