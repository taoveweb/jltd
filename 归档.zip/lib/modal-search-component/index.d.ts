import * as React from 'react';
export interface ModalSearchComponentControllerProps {
    visible: boolean;
    onCancel: (e?: any) => void;
    onChangeVisible: Function;
    queryList: Function;
    dataSource: any;
    columns: any;
    moadlObject: any;
    modalTitle: String;
    type?: String;
    form: any;
}
export interface ModalSearchComponentControllerState {
    categoryCurrent: Number;
    selectCategoryRow: Array<any>;
    selectedRowKeys: Array<any>;
    categoryDataSource: Array<any>;
    selectOwnerRow: Array<any>;
    ownerRecord: Array<any>;
}
declare const _default: React.ComponentClass<import("../../../../../../../Users/sinoservices/Documents/new/jlt-design/node_modules/antd/lib/form/Form").RcBaseFormProps & Pick<ModalSearchComponentControllerProps, "visible" | "type" | "onCancel" | "dataSource" | "columns" | "onChangeVisible" | "queryList" | "moadlObject" | "modalTitle">, React.ComponentState>;
export default _default;
