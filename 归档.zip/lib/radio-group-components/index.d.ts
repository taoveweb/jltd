import * as React from 'react';
export interface RadioGroupComponentsProps {
    codeType: any;
    onChange?: (e?: any) => void;
    disabled?: boolean;
    value?: any;
    defaultValue?: any;
}
export interface RadioGroupComponentsState {
    dataDictionaryList: Array<any>;
    loading: boolean;
}
declare class RadioGroupComponents extends React.Component<RadioGroupComponentsProps, RadioGroupComponentsState> {
    constructor(props: RadioGroupComponentsProps);
    componentWillMount(): void;
    searchTemplateForState: () => void;
    render(): JSX.Element;
}
export default RadioGroupComponents;
