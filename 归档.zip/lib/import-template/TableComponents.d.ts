import { Component } from 'react';
declare class TableComponents extends Component<any, any> {
    columns: any;
    cacheData: any;
    constructor(props: any);
    componentWillReceiveProps(nextProps: any): void;
    onSelectChange: (selectedRowKeys: any, selectedRows: any) => void;
    getTableDataSource(tableData?: Array<any>, isAddable?: boolean): any;
    getLastTableDataMap: (key: any) => any;
    handleChange: (value: any, record: any, column: any) => void;
    delete(index: any): void;
    edit(index: any): void;
    save(index: any): void;
    add(key: any): void;
    cancel(index: any): void;
    renderColumns: (text: any, record: any, column: any) => JSX.Element;
    renderAColumns: (text: any, record: any, column: any) => JSX.Element;
    render(): JSX.Element;
}
export default TableComponents;
