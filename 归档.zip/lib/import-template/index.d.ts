import ImportTemplate from './importTemplate';
export default ImportTemplate;
