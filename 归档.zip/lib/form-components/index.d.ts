import * as React from 'react';
export interface FormComponentsProps {
    getRefForm: any;
    form: any;
    placeholder: any;
    value: any;
    handleSubmit: (e?: any) => void;
    datas?: Array<{
        isRequire?: boolean;
        type: string;
        onChange: Function;
        value?: any;
        codeType?: string;
        defaultValue?: string;
        className?: string;
        dropdownMatchSelectWidth?: boolean;
        mode?: string;
        style?: Object;
        col?: any;
        placeholder?: string;
        optionData?: Array<{
            value: string;
            text: string;
        }>;
        radioData?: Array<{
            value: string;
            text: string;
        }>;
    }>;
}
export interface FormComponentsState {
    dataDictionaryList: Array<any>;
    loading: boolean;
}
declare const _default: React.ComponentClass<import("../../../../../../../Users/sinoservices/Documents/new/jlt-design/node_modules/antd/lib/form/Form").RcBaseFormProps & Pick<FormComponentsProps, "placeholder" | "value" | "handleSubmit" | "getRefForm" | "datas">, React.ComponentState>;
export default _default;
