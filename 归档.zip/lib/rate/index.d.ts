import { Rate } from 'antd';
export default Rate;
