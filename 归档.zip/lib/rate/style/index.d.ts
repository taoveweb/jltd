import 'antd/lib/style/index.less';
import 'antd/lib/rate/style/index.less';
