/// <reference types="react" />
declare const AvatarList: ({ children, size, ...other }: any) => JSX.Element;
export default AvatarList;
