import { Avatar } from 'antd';
export default Avatar;
