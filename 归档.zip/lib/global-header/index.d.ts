import * as React from 'react';
interface IGlobalHeaderProps {
    notices?: any;
    collapsed?: any;
    onCollapse?: any;
    currentUser?: any;
    isMobile?: any;
    logo?: any;
    onNoticeVisibleChange?: any;
    onMenuClick?: any;
    onNoticeClear?: any;
}
export default class GlobalHeader extends React.PureComponent<IGlobalHeaderProps, any> {
    props: any;
    componentWillUnmount(): void;
    toggle: () => void;
    triggerResizeEvent(): void;
    renderUserinfo: () => JSX.Element[];
    render(): JSX.Element;
}
export {};
