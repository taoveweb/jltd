import 'antd/lib/style/index.less';
import 'antd/lib/message/style/index.less';
