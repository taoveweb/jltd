import * as React from 'react';
interface IEditableItem {
    value?: any;
    onChange?: any;
}
export default class EditableItem extends React.PureComponent<IEditableItem, any> {
    constructor(props: IEditableItem);
    handleChange: (e: any) => void;
    check: () => void;
    edit: () => void;
    render(): JSX.Element;
}
export {};
