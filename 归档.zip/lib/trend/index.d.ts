/// <reference types="react" />
declare const Trend: ({ colorful, reverseColor, flag, children, className, ...rest }: any) => JSX.Element;
export default Trend;
