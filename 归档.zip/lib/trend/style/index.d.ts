import '../../icon/style';
import './index.less';
