import { InputNumber } from 'antd';
export default InputNumber;
