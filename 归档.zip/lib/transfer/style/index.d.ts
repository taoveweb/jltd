import 'antd/lib/style/index.less';
import 'antd/lib/transfer/style/index.less';
import 'antd/lib/checkbox/style';
import 'antd/lib/button/style';
import 'antd/lib/input/style';
