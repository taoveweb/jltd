import { Transfer } from 'antd';
export default Transfer;
