import * as React from 'react';
declare class AuthorizedRoute extends React.Component {
    render(): JSX.Element;
}
export default AuthorizedRoute;
