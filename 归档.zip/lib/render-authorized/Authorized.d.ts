import * as React from 'react';
interface IAuthorizedProps {
    children?: any;
    authority?: any;
    noMatch?: any;
}
declare class Authorized extends React.Component<IAuthorizedProps, any> {
    static Secured: any;
    static AuthorizedRoute: any;
    static check: any;
    static PromiseRender: any;
    static renderAuthorize: any;
    render(): any;
}
export default Authorized;
