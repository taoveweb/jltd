import * as React from 'react';
interface IPromiseRenderProps {
    ok?: any;
    error?: any;
    promise?: any;
}
export default class PromiseRender extends React.PureComponent<IPromiseRenderProps, any> {
    state: {
        component: null;
    };
    componentDidMount(): void;
    componentWillReceiveProps(nextProps: any): void;
    setRenderComponent(props: any): void;
    checkIsInstantiation: (target: any) => any;
    render(): JSX.Element;
}
export {};
