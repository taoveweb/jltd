/**
 * 通用权限检查方法
 * Common check permissions method
 * @param { 权限判定 Permission judgment type string |array | Promise | Function } authority
 * @param { 你的权限 Your permission description  type:string} currentAuthority
 * @param { 通过的组件 Passing components } target
 * @param { 未通过的组件 no pass components } Exception
 */
declare const checkPermissions: (authority: any, currentAuthority: any, target: any, Exception: any) => any;
export { checkPermissions };
declare const check: (authority: any, target: any, Exception: any) => any;
export default check;
