declare const _default: (currentAuthority: any) => any;
export default _default;
