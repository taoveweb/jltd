declare let CURRENT: string;
export { CURRENT };
declare const _default: (Authorized: any) => (currentAuthority: any) => any;
export default _default;
