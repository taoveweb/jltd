import * as React from 'react';
declare const TagSelectOption: any;
export interface ITagSelectProps {
    onChange?: (value: string[]) => void;
    expandable?: boolean;
    value?: string[] | number[];
    className?: string;
    prefixCls?: string;
    defaultValue?: string[] | number[];
    style?: React.CSSProperties;
}
declare class TagSelect extends React.Component<ITagSelectProps, any> {
    static Option: typeof TagSelectOption;
    constructor(props: ITagSelectProps);
    componentWillReceiveProps(nextProps: ITagSelectProps): void;
    onChange: (value: any) => void;
    onSelectAll: (checked: any) => void;
    getAllTags(): any[];
    handleTagChange: (value: any, checked: any) => void;
    handleExpand: () => void;
    isTagSelectOption: (node: any) => any;
    render(): JSX.Element;
}
export default TagSelect;
