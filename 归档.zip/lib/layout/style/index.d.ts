import 'antd/lib/style/index.less';
import 'antd/lib/layout/style/index.less';
