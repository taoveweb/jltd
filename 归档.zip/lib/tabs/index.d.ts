import { Tabs } from 'antd';
export default Tabs;
