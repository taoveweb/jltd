import '../../alert/style';
import '../../table/style';
import './index.less';
