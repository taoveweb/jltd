import * as React from 'react';
declare type StandardTableState = {
    selectedRowKeys: undefined[];
    needTotalList: any[];
};
interface StandardTableProps {
    loading: any;
    rowKey: any;
    columns: any;
    selectedRows: any;
    onSelectRow: any;
    data: any;
    prefixCls?: string;
    className?: string;
    onChange: (a: any, b: any, c: any) => void;
}
declare class StandardTable extends React.PureComponent<StandardTableProps, StandardTableState> {
    constructor(props: StandardTableProps);
    componentWillReceiveProps(nextProps: StandardTableProps): void;
    handleRowSelectChange: (selectedRowKeys: any, selectedRows: any) => void;
    handleTableChange: (pagination: any, filters: any, sorter: any) => void;
    cleanSelectedKeys: () => void;
    render(): JSX.Element;
}
export default StandardTable;
